<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
</head>
<body>
    <h1>Apartment Management System</h1>
    <h2>Account Tester</h2>
    <p>Please choose an option:</p>
    <ul>
        <li><a href="login.php">Login</a></li>
        <li><a href="signup.php">Sign Up</a></li>
        <li><a href="forgotpass.php">Forgot Password?</a></li>
    </ul>
</body>
</html>
